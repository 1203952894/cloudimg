"""
Author: C
Name: doMain02
Time: 2022/10/27 8:10
TO: 记录学习 人脸检测

步骤：
1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client
2. 调用人脸对比接口函数，保存输出结果
3. 解析处理结果
"""
import base64
import os
import time

from PIL import Image
from aip import AipFace

# 1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client
APP_ID = '28107745'
API_KEY = '9aSbBoWipgTqzfL7s7ZN9zVQ'
SECRET_KEY = 'iEwrVGO4Gl4yXyjnnG73RqwlIht4FYaE'

client = AipFace(APP_ID, API_KEY, SECRET_KEY)
print(client)
# 2. 调用人脸对比接口函数，保存输出结果
oldFiles = os.listdir("old")
newFiles = os.listdir("new")
for oldFile in oldFiles:
    oldFile = 'old/' + oldFile
    for newFile in newFiles:
        newFile = 'new/' + newFile
        result = client.match([
            {
                'image': base64.b64encode(open(oldFile, 'rb').read()).decode(),
                'image_type': 'BASE64',
            },
            {
                'image': base64.b64encode(open(newFile, 'rb').read()).decode(),
                'image_type': 'BASE64',
            }
        ])
        # 3. 解析处理结果
        similarity = result['result']['score']
        print(similarity)
        if similarity > 75:
            print(oldFile, '和', newFile, '是同一个人', f'相似度得分为{similarity}')
            Image.open(oldFile).show()
            Image.open(newFile).show()
        else:
            print("相似度 similarity 小于 75")
        # 通过手动设置休眠时间 减少 QPS 的访问率
        time.sleep(0.5)
