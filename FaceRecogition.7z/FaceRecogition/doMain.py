"""
Author: C
Name: doMain
Time: 2022/10/27 8:10
TO: 记录学习 人脸检测

步骤：
1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client
2. 调用人脸对比接口函数，保存输出结果
3. 解析处理结果
"""
import base64

from aip import AipFace

# 1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client
APP_ID = '28107745'
API_KEY = '9aSbBoWipgTqzfL7s7ZN9zVQ'
SECRET_KEY = 'iEwrVGO4Gl4yXyjnnG73RqwlIht4FYaE'

client = AipFace(APP_ID, API_KEY, SECRET_KEY)
print(client)
# 2. 调用人脸对比接口函数，保存输出结果
oldFile = 'old/old01.jpg'
newFile = 'new/new01.jpg'

result = client.match([
    {
        'image': base64.b64encode(open(oldFile, 'rb').read()).decode(),
        'image_type': 'BASE64',
    },
    {
        'image': base64.b64encode(open(newFile, 'rb').read()).decode(),
        'image_type': 'BASE64',
    }
])
print(result)

{
    'error_code': 0,
    'error_msg': 'SUCCESS',
    'log_id': 1952001528,
    'timestamp': 1666834352,
    'cached': 0,
    'result': {
        'score': 91.97103882,
        'face_list': [
            {
                'face_token': 'f19a80c260999b30cc9f1dc37f1b291e'
            },
            {
                'face_token': '8056067de93d9832a0201f74821a5a02'
            }
        ]
    }
}

# 3. 解析处理结果
similarity = result['result']['score']
print(similarity)
if similarity > 75:
    print(oldFile, '和', newFile, '是同一个人', f'相似度得分为{similarity}')
