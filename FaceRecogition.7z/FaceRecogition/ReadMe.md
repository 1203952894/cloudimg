# 使用百度 AI 进行人脸识别检测

> Author: C
> Time: 2022/10/27 8:10
> TO: 记录学习 人脸检测

## 一、准备

> 1. 工程创建
> 2. 资源配置
> 3. 编写代码并运行测试
> 4. 改进

### 1. 工程创建

> - 新建文件夹 old 和 new ，将人脸图片放在 old文件夹中
> - 在 pycharm 中创建 FaceRecognition 包,并创建脚本文件 doMain.py 用于编写代码

![image.png](assets/image.png)

### 2. 资源配置

> - 在百度大脑控制台中找到 人脸检测并点击 公有云服务的应用列表
>   在应用列表中创建应用，创建时 接口选择 要按照微信群中的截图进行选择

![image.png](assets/1666831116033-image.png)

> 在 文字识别 选项框中：

![image.png](assets/1666831441386-image.png)

> 在 自然语言处理及内容审核 选项框中：

![image.png](assets/1666831467770-image.png)

![image.png](assets/1666831547691-image.png)

### 3.编写代码并运行测试

> 1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client

```python
APP_ID = '28107745'
API_KEY = '9aSbBoWipgTqzfL7s7ZN9zVQ'
SECRET_KEY = 'iEwrVGO4Gl4yXyjnnG73RqwlIht4FYaE'

client = AipFace(APP_ID, API_KEY, SECRET_KEY)
print(client)
```

![image.png](./assets/1666833347066-image.png)

> 2. 调用人脸对比接口函数，保存输出结果

```python
oldFile = 'old/old01.jpg'
newFile = 'new/new01.jpg'

result = client.match([
    {
        'image': base64.b64encode(open(oldFile, 'rb').read()).decode(),
        'image_type': 'BASE64',
    },
    {
        'image': base64.b64encode(open(newFile, 'rb').read()).decode(),
        'image_type': 'BASE64',
    }
])
print(result)
```

![image.png](./assets/1666834908128-image.png)

> 3. 解析处理结果

```python
similarity = result['result']['score']
print(similarity)
if similarity > 75:
    print(oldFile, '和', newFile, '是同一个人', f'相似度得分为{similarity}')
```

![image.png](./assets/1666835014508-image.png)

### 4. 改进

> 上面我们检测的方式是一对一，这样存在效率低下的问题，接下来我们将对其进行改进（一对多）
>
> 需要注意的是： 免费资源会存在 QPS 限制（即每秒可接受的处理最多为2条） 但程序执行的速度是非常快的这个时候我们可以通过手动设置程序休眠来达到类似效果即 time.sleep（） 函数

> 1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client

```python
# 1. 通过 APP_ID、API_KEY、 SECRET_KEY 获取连接对象 client
APP_ID = '28107745'
API_KEY = '9aSbBoWipgTqzfL7s7ZN9zVQ'
SECRET_KEY = 'iEwrVGO4Gl4yXyjnnG73RqwlIht4FYaE'

client = AipFace(APP_ID, API_KEY, SECRET_KEY)
print(client)
```

> 2. 对数据进行处理

```python
# 2. 调用人脸对比接口函数，保存输出结果
oldFiles = os.listdir("old")
newFiles = os.listdir("new")
for oldFile in oldFiles:
    oldFile = 'old/' + oldFile
    for newFile in newFiles:
        newFile = 'new/' + newFile
        result = client.match([
            {
                'image': base64.b64encode(open(oldFile, 'rb').read()).decode(),
                'image_type': 'BASE64',
            },
            {
                'image': base64.b64encode(open(newFile, 'rb').read()).decode(),
                'image_type': 'BASE64',
            }
        ])
        # 3. 解析处理结果
        similarity = result['result']['score']
        print(similarity)
        if similarity > 75:
            print(oldFile, '和', newFile, '是同一个人', f'相似度得分为{similarity}')
        else:
            print("相似度 similarity 小于 75")
        # 通过手动设置休眠时间 减少 QPS 的访问率
        time.sleep(0.5)
```

![image.png](./assets/1667436861933-image.png)
